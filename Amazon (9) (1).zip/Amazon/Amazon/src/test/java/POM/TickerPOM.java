package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TickerPOM {

	
WebDriver driver;
	
	public TickerPOM(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
@FindBy(xpath="(//input[@name='txtSearchComp']")
  WebElement searchbox;
	
@FindBy(xpath="(//span[@class='badge badge-primary'])[1]")
WebElement Click;


}
