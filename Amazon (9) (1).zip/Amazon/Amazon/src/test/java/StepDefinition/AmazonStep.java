package StepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import POM.AmazonPOM;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AmazonStep {
	WebDriver driver;
	public AmazonPOM ap;
	@Given("Launch the browser")
	public void launch_the_browser() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
	
		
	}

	@When("User enter url and is on home page")
	public void user_enter_url_and_is_on_home_page() {
		driver.get("https://www.amazon.in/");
		//ap=new AmazonPOM(driver);
	}

	@When("User Enter the text t-shirt for woman")
	public void user_enter_the_text_t_shirt_for_woman() {
		
		
	WebElement Searchbox=driver.findElement(By.xpath("//input[@name='field-keywords']"));
	Searchbox.click();
		
	}

	@When("User Enter the text box")
	public void user_enter_the_text_box() {
		WebElement Searchbox=driver.findElement(By.xpath("//input[@name='field-keywords']"));
		Searchbox.sendKeys("T-shirt for women");
		
		WebElement Search=driver.findElement(By.xpath("//div[@class='nav-search-submit nav-sprite']"));
		Search.click();
		
		
		
	}

	@Then("User see the list of shirts")
	public void user_see_the_list_of_shirts() {
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,350)");
		
	}

	@Then("User click on particular T-shirt")
	public void user_click_on_particular_t_shirt() throws InterruptedException {
		WebElement Tshirt=driver.findElement(By.xpath("(//img[@class='s-image'])[3]"));
		Tshirt.click();
		Thread.sleep(5000);
		
	}

	@Then("Click on add to cart button")
	public void click_on_add_to_cart_button() {
		WebElement element = driver.findElement(By.xpath("//input[@name='submit.add-to-cart']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		element.click();
		
	}


}
