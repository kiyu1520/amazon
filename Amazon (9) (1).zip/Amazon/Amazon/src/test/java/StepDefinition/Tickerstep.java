package StepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import POM.TickerPOM;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class Tickerstep {

	public TickerPOM Tp;
	WebDriver driver;
	@Given("Enter a URL")
	public void enter_a_url() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
	  
	}

	@When("Enter a search box")
	public void enter_a_search_box() {
		driver.get("https://ticker.finology.in/");
		WebElement Searchbox=driver.findElement(By.xpath("(//a[@class='list animated fadeInUp faster'])[1]"));
		Searchbox.click();
			  
	}

	@When("User enter a infosys Ltd")
	public void user_enter_a_infosys_ltd() {
		WebElement Searchbox=driver.findElement(By.xpath("(//a[@class='list animated fadeInUp faster'])[1]"));
		Searchbox.click();
		
		
	}
}
